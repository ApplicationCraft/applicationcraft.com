Contents:


A: app_Adaptive+Video_r44.acft
B: GDS_and_SwitchApp_Package.zip


Instructions;

1:Extract the contents of this Zip file

2: GDS_and_SwtichApp_Package.zip contains 3 seperate apps that are all related and will require editing before they will run as you see in the Video.

3: Extract the contents of that zip and refer to the included ReadMe.txt file for the required actions


4: To import the apps,  log into your Application Craft Account

Go to the Apps tab, and select the 'Import' option.

As you import more of these tutorial apps that are using the same 'theme' you will get a notice
'Some dependencies of this App already exist. Do you want to....'
Select the 'Recreate' option 
