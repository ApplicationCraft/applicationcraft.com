Contents:


A: app_Adaptive+Video.acft

Instructions;

1:Extract the contents of this Zip file

2: To import the apps,  log into your Application Craft Account

Go to the Apps tab, and select the 'Import' option and select the acft file.

