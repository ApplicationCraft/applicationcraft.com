Contents:


A: app_Integration+Minimum+JS_r1.acft
B: app_Integration+Maximum+JS_r1.acft

Instructions;

1:Extract the contents of this Zip file

2: To import the apps,  log into your Application Craft Account

Go to the Apps tab, and select the 'Import' option.

As you import more of these tutorial apps that are using the same 'theme' you will get a notice
'Some dependencies of this App already exist. Do you want to....'
Select the 'Recreate' option 
