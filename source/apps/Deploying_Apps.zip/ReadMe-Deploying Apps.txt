Contents:


A: app_Web+Services+Simple+Map_r3.acft


Instructions;

1: Extract the contents of this Zip file

2: To import the apps,  log into your Application Craft Account

Go to the Apps tab, and select the 'Import' option.


Please Note: Although this app will currently run 'as is' it does not use a GoogleMap API keys. 
To ensure that you do not experience any problem with this app we would recommend you sign up for your own key now.

To do this: open the app in 'Edit' mode, 
select the Map widget and from the property bar, 
click the Google API Key. 
Within that window is a link to 'Sign Up to get Google Api Key',
follow that link and the instructions given by google, 
then back in the 'List of Items' window,
'Add Row' and enter in your account domain name in the Host Name field, 
and your API key in the Google Map Key field.
Save to close the window.
Save your app and you are ready to go

and also any future use of the GoogleMap widget will then use your own key 
