Contents:


A: app_Starting+Off_r2.acft
B: app_Lists_r1.acft
C: app_Error+Handling_r2.acft
D: app_Web+Services+Simple+Map_r3.acft
E: app_Web+Services+Weather_r2.acft



Instructions;

1: Extract the contents of this Zip file

2: To import the apps,  log into your Application Craft Account

Go to the Apps tab, and select the 'Import' option.

Please note, since the Video's were created, the new GoogleMap Advanced widget has been released and supports easier methods of working with the the Google Geocoding API

As you import more of these tutorial apps that are using the same 'theme' you will get a notice
'Some dependencies of this App already exist. Do you want to....'
Select the 'Recreate' option 
