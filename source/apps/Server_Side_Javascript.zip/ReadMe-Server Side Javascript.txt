Contents:


A: app_DB+Demo_r4.acft


Instructions;

1: Extract the contents of this Zip file

2: To import the apps,  log into your Application Craft Account

Go to the Apps tab, and select the 'Import' option.

As you import more of these tutorial apps that are using the same 'theme' you will get a notice
'Some dependencies of this App already exist. Do you want to....'
Select the 'Recreate' option 

Please Note: This app will not run 'as is'. The connection to our database is not included in this app. If you wish to run this app you will need to 
a) set up a database with the appropriate table/field names. See http://www.applicationcraft.com/developers/documentation/product-guide/data-storage/server-side-data-storage/a-simple-example/create-the-example-database/ for example code to create this example database
b) set up a connection to your database table in your account, and not the connection ID
c) edit the ssj.getConnection() to your connnection ID - this is in the function acDemoWS()
d) Save the app before running in Preview or Live Mode
